"""Research-lead-authored remote collector. Run once in Muse; no analysis."""
from pathlib import Path
from datetime import datetime, timezone
import csv, hashlib, json, random, subprocess, time, zipfile
def now(): return datetime.now(timezone.utc).isoformat()
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
cases=[('A','All-Clad','all-clad.com','stainless steel frying pan'),('L','Levoit','levoit.com','small air purifier for a bedroom'),('H','Hydro Flask','hydroflask.com','32 oz stainless steel insulated water bottle')]
conditions=['C0','C1','C2','C3','C4','C5','C6']
rng=random.Random(20260927);schedule=[]
for block in range(1,4):
    cells=[(c,k) for c in cases for k in conditions];rng.shuffle(cells)
    for slot,((case,brand,domain,query),condition) in enumerate(cells,1):
        flags={'C0':[],'C1':[],'C2':['--brand',brand],'C3':['--prefer-brand',brand],'C4':['--domain',domain],'C5':['--brand',brand,'--domain',domain],'C6':['--prefer-brand',brand,'--domain',domain]}[condition]
        q=brand+' '+query if condition=='C1' else query
        argv=['/opt/hatch/bin/meta-catalog-search','--query',q]+flags+['-n','50','--conversation-id','brand-replication-20260927-'+case,'--retries','0','--timeout-secs','30','--raw','--no-save']
        n=len(schedule)+1
        schedule.append(dict(run_id=f'R{n:02}',stem=f'R{n:02}-{case}-{condition}',block=block,slot=slot,case=case,condition=condition,brand=brand,domain=domain,argv=argv))
stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
out=Path.home()/'workspace'/'research-evidence'/('brand-replication-'+stamp)
out.mkdir(parents=True,exist_ok=False)
(out/'collector.py').write_bytes(Path(__file__).read_bytes())
(out/'schedule.json').write_text(json.dumps(schedule,indent=2)+'\n')
executions=[];unavailable=False
for item in schedule:
    stem=item['stem'];argv=item['argv']
    (out/(stem+'.argv.json')).write_text(json.dumps(argv,indent=2)+'\n')
    stdout=out/(stem+'.stdout.raw-bytes');stderr=out/(stem+'.stderr.raw-bytes')
    start=now();clock=time.monotonic();code=None;error=None
    with stdout.open('wb') as so,stderr.open('wb') as se:
        try: code=subprocess.run(argv,stdout=so,stderr=se,timeout=45,check=False).returncode
        except subprocess.TimeoutExpired: error='Collector timeout after45 seconds; no retry.'
        except (FileNotFoundError,PermissionError) as exc:
            error=f'{type(exc).__name__}: {exc}';unavailable=True
    record=dict(item,utc_start=start,utc_end=now(),elapsed_ms=round((time.monotonic()-clock)*1000,3),exit_code=code,observed_error=error,stdout_file=stdout.name,stdout_bytes=stdout.stat().st_size,stdout_sha256=sha(stdout),stderr_file=stderr.name,stderr_bytes=stderr.stat().st_size,stderr_sha256=sha(stderr),origin='Collector recorded this subprocess invocation; no manual transcription.')
    (out/(stem+'.execution.json')).write_text(json.dumps(record,indent=2)+'\n')
    executions.append(record)
    if unavailable: break
(out/'collection-status.json').write_text(json.dumps(dict(scheduled=len(schedule),attempted=len(executions),stopped_for_launch_error=unavailable,completed_utc=now()),indent=2)+'\n')
files=sorted(out.iterdir())
with (out/'MANIFEST.csv').open('w',newline='') as f:
    w=csv.writer(f);w.writerow(['path','bytes','sha256'])
    for p in files: w.writerow([p.name,p.stat().st_size,sha(p)])
archive=out.with_suffix('.zip')
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for p in sorted(out.iterdir()): z.write(p,arcname=out.name+'/'+p.name)
with zipfile.ZipFile(archive) as z: assert z.testzip() is None
print(json.dumps(dict(archive_path=str(archive),bytes=archive.stat().st_size,sha256=sha(archive),scheduled=len(schedule),attempted=len(executions),exit_codes=[r['exit_code'] for r in executions]),indent=2))
