"""Research-lead-authored follow-up collection, run remotely once. No analysis."""
from pathlib import Path
from datetime import datetime,timezone
import csv,hashlib,json,random,subprocess,time,zipfile
def now(): return datetime.now(timezone.utc).isoformat()
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
cases=[('M','Misen','misen.com','stainless steel frying pan'),('A','All-Clad','all-clad.com','stainless steel frying pan'),('L','Levoit','levoit.com','small air purifier for a bedroom'),('H','Hydro Flask','hydroflask.com','32 oz stainless steel insulated water bottle')]
schedule=[];rng=random.Random(20260928)
def add(stage,case,condition,block,argv,domain='',brand='',output=False):
    n=len(schedule)+1
    schedule.append(dict(run_id=f'R{n:02}',stem=f'R{n:02}-{stage}-{case}-{condition}',stage=stage,case=case,condition=condition,block=block,domain=domain,brand=brand,argv=argv,parsed_output_requested=output))
def base(q,cid,n=50,brand=None):
    return ['/opt/hatch/bin/meta-catalog-search','--query',q]+(['--brand',brand] if brand else [])+['-n',str(n),'--conversation-id',cid,'--retries','0','--timeout-secs','30']
for block in range(1,4):
    cells=[(c,n) for c in cases for n in [10,50,100]];rng.shuffle(cells)
    for (case,brand,domain,q),n in cells:
        add('count',case,'n'+str(n),block,base(q,'count-followup-20260927-'+case,n,brand)+['--raw','--no-save'],domain,brand)
for block in range(1,4):
    cells=[(c,mode) for c in [cases[0],cases[3]] for mode in ['fixed','fresh']];rng.shuffle(cells)
    for (case,brand,domain,q),mode in cells:
        cid='context-followup-20260927-'+case+('-fixed' if mode=='fixed' else '-fresh-'+str(block))
        add('context',case,mode,block,base(q,cid,50,brand)+['--raw','--no-save'],domain,brand)
for case,brand,domain,q in [cases[1],cases[2]]:
    for slot,mode in enumerate(['raw','stdout','raw'],1):
        add('bracket',case,str(slot)+'-'+mode,1,base(q,'mode-bracket-20260927-'+case,50,brand)+['--'+mode,'--no-save'],domain,brand)
for mode in ['raw','json','stdout']:
    add('dual','M',mode,1,base(cases[0][3],'mode-dual-20260927-M',50,'Misen')+['--'+mode,'--out','{PARSED_OUT}'],'misen.com','Misen',True)
add('meta','platform','uname',1,['uname','-srm'])
add('meta','catalog','help',1,['/opt/hatch/bin/meta-catalog-search','--help'])
add('meta','python','version',1,['python3','--version'])
stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
out=Path.home()/'workspace'/'research-evidence'/('catalog-followup-'+stamp)
out.mkdir(parents=True,exist_ok=False)
(out/'collector.py').write_bytes(Path(__file__).read_bytes())
(out/'schedule.json').write_text(json.dumps(schedule,indent=2)+'\n')
executions=[];unavailable=False
for item in schedule:
    stem=item['stem'];parsed=out/(stem+'.parsed-output.json')
    argv=[str(parsed) if a=='{PARSED_OUT}' else a for a in item['argv']]
    (out/(stem+'.argv.json')).write_text(json.dumps(argv,indent=2)+'\n')
    so=out/(stem+'.stdout.raw-bytes');se=out/(stem+'.stderr.raw-bytes')
    start=now();clock=time.monotonic();code=None;error=None
    with so.open('wb') as a,se.open('wb') as b:
        try: code=subprocess.run(argv,stdout=a,stderr=b,timeout=45,check=False).returncode
        except subprocess.TimeoutExpired: error='Collector timeout after45seconds; no retry.'
        except (FileNotFoundError,PermissionError) as exc:
            error=f'{type(exc).__name__}: {exc}';unavailable=True
    rec=dict(item,argv_actual=argv,utc_start=start,utc_end=now(),elapsed_ms=round((time.monotonic()-clock)*1000,3),exit_code=code,observed_error=error,stdout_file=so.name,stdout_bytes=so.stat().st_size,stdout_sha256=sha(so),stderr_file=se.name,stderr_bytes=se.stat().st_size,stderr_sha256=sha(se),parsed_output_exists=parsed.is_file())
    if parsed.is_file(): rec.update(parsed_output_file=parsed.name,parsed_output_bytes=parsed.stat().st_size,parsed_output_sha256=sha(parsed))
    (out/(stem+'.execution.json')).write_text(json.dumps(rec,indent=2)+'\n');executions.append(rec)
    if unavailable: break
(out/'collection-status.json').write_text(json.dumps(dict(scheduled=len(schedule),attempted=len(executions),stopped_for_launch_error=unavailable,completed_utc=now()),indent=2)+'\n')
files=sorted(out.iterdir())
with (out/'MANIFEST.csv').open('w',newline='') as f:
    w=csv.writer(f);w.writerow(['path','bytes','sha256'])
    for p in files: w.writerow([p.name,p.stat().st_size,sha(p)])
archive=out.with_suffix('.zip')
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for p in sorted(out.iterdir()): z.write(p,arcname=out.name+'/'+p.name)
with zipfile.ZipFile(archive) as z: assert z.testzip() is None
print(json.dumps(dict(archive_path=str(archive),bytes=archive.stat().st_size,sha256=sha(archive),scheduled=len(schedule),attempted=len(executions),exit_codes=[r['exit_code'] for r in executions]),indent=2))
