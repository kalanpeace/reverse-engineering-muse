#!/bin/bash
# Triple verification for function range 0x4a2ea0..0x4a305a (end exclusive).
# Bounds verified against funcs.txt (eh_frame): 0x4a2ea0..0x4a305a.
# VA->file mapping: .text VA 0x3290c0 = file 0x3280c0 (delta 0x1000).
# file_start = 0x4a2ea0 - 0x1000 = 0x4a1ea0 ; byte count = 0x4a305a - 0x4a2ea0 = 442
set -u
BIN=/opt/hatch/bin/meta-catalog-search
D=~/workspace/research-evidence/ordering-evidence-2026-09-26/triple-verify
cd "$D"
echo "=== tool versions ==="
objdump --version | head -1
od --version | head -1
/tmp/capvenv/bin/python -c "import capstone; print('capstone', capstone.__version__)"
echo "=== binary identity ==="
sha256sum "$BIN"
readelf -n "$BIN" | grep -A1 "Build ID"
echo "=== A: dd byte extraction ==="
dd if="$BIN" of="$D/range-0x4a2ea0.bin" bs=1 skip=$((0x4a1ea0)) count=442 status=none
echo "dd exit=$?"
sha256sum "$D/range-0x4a2ea0.bin"
wc -c "$D/range-0x4a2ea0.bin"
echo "=== A: hex dump (od) ==="
od -A x -t x1z "$D/range-0x4a2ea0.bin"
echo "=== C: objdump disassembly of identical range ==="
objdump -d -M intel --start-address=0x4a2ea0 --stop-address=0x4a305a "$BIN"
echo "objdump exit=$?"
echo "=== C availability check: llvm-objdump ==="
which llvm-objdump || echo "llvm-objdump: NOT INSTALLED (unavailable, not simulated)"
