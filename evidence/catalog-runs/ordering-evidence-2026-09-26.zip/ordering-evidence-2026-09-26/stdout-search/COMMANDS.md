# Item 3 command log — response-read to --raw stdout branch hunt
# Binary: /opt/hatch/bin/meta-catalog-search
# sha256: db8bcb0c16143c71d1d0d320ad2a16404efa723ed2db582f39e9340e59465702
# Build ID: e9c8beff451ffdb7c933c3f5e4a318e8bd0089f9
# Capstone 5.0.7 via /tmp/capvenv; GNU objdump 2.42; readelf; strings (all preinstalled)

## Step 1 — direct callers of 0x4bb230 (parse-path entry)
/tmp/capvenv/bin/python - <<'EOF'
import sys, struct
sys.path.insert(0,'/tmp/capvenv/lib/python3.12/site-packages')
from capstone import Cs, CS_ARCH_X86, CS_MODE_64
data=open('/opt/hatch/bin/meta-catalog-search','rb').read()
TEXT_OFF=0x3280c0; TEXT_VA=0x3290c0; TEXT_SZ=0x77b903
target=0x4bb230
md=Cs(CS_ARCH_X86, CS_MODE_64)
code=data[TEXT_OFF:TEXT_OFF+TEXT_SZ]
callers=[]
for ins in md.disasm(code, TEXT_VA):
    b=ins.bytes
    if b[0:1]==b'\xe8' and len(b)==5:
        tgt=ins.address+5+struct.unpack('<i',b[1:5])[0]
        if tgt==target:
            callers.append(ins.address)
print('direct callers of 0x4bb230:', [hex(c) for c in callers])
EOF
# result: NONE

## Step 2 — lea/mov-immediate refs to 0x4bb230 : NONE (script in shell history)

## Step 3 — tail jumps (e9/eb) to 0x4bb230 : NONE (script in shell history)

## Step 4 — qword pointer scan for 0x4bb230 across whole file
# result: 2 hits -> .rela.dyn file 0x97410 and .got file 0xB1AA58 (VA 0xB1CA58)
# output: stdout-search/ptr-scan.txt

## Step 5 — decode RELA entry at file 0x97400
# result: r_offset=0xb1ca58 r_info type=8 (R_X86_64_RELATIVE) r_addend=0x4bb230
# output: stdout-search/got-xref2.txt

## Step 6 — any rip-relative code ref to GOT slot VA 0xb1ca58
# result: exactly 1 -> 0x411a9f: ff 15 b3 af 70 00  call qword ptr [rip + 0x70afb3]
# output: stdout-search/got-xref2.txt

## Step 7 — enclosing function of 0x411a9f from v2 funcs.txt
# result: 0x40d100..0x413a2d (26925 bytes); full disassembly exported
# output: stdout-search/caller-region.txt (4805 instructions, Capstone 5.0.7)

## Step 8 — guard region around the indirect call (from caller-region.txt)
# 0x411a6d: cmp byte ptr [rbx + 0x543], 0 ; je 0x412f85 (skips parse region)
# 0x411a7a: mov eax,0xffffff38 ; add eax,[rbx+0x898] ; cmp ax,0x64 ; jae 0x411aa7
# 0x411a9f: call qword ptr [rip+0x70afb3]  -> 0x4bb230 (parse path)
# 0x412fcc / 0x413038: same [rbx+0x898] 2xx range check on alternate paths
#   (lea eax,[rsi-0xc8] ; cmp ax,0x64  =>  status in [200,300) )
# Flag bytes [rbx+0x543/544/545] are only READ in 0x40d100, never written there.

## Step 9 — CLI contract strings
strings -a /opt/hatch/bin/meta-catalog-search | grep -i 'raw'
# result includes: "RAWPrint raw HTTP response bodyPrint parsed JSON (full response wrapper)"
# "Print raw HTTP response body" at file 0x205f8d (.rodata), 1 occurrence
# output: stdout-search/rawstring-scan.txt

## Step 10 — skip-path target 0x412f85 region inspected; leads to 0x413221
# (cleanup/exit region; no stdout body-write identified)
# No instruction sequence writing response-body bytes to stdout was identified.
