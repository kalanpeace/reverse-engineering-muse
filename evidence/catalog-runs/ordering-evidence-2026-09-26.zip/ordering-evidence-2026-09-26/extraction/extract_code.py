#!/usr/bin/env python3
"""Evidence extraction: byte slices + disassembly for cited code ranges.

Reads /opt/hatch/bin/meta-catalog-search, maps link-time VAs to file offsets
via the .text section mapping (.text VA 0x3290c0 = file offset 0x3280c0),
writes raw .bin slices and Capstone disassembly (VA, exact bytes, mnemonic,
operands). Writes va-map.txt, binary identity (sha256, build-id), and a
run log. No hand-typed assembly; no analysis.
"""
import sys, hashlib, os
sys.path.insert(0, '/tmp/capvenv/lib/python3.12/site-packages')
from capstone import Cs, CS_ARCH_X86, CS_MODE_64

BIN = '/opt/hatch/bin/meta-catalog-search'
OUT = os.path.dirname(os.path.abspath(__file__)) + '/../code-slices'
os.makedirs(OUT, exist_ok=True)

TEXT_VA, TEXT_OFF = 0x3290c0, 0x3280c0

RANGES = {
    'pass-0x4a2ea0':   (0x4a2ea0, 0x4a305a),
    'pass-0x4a2cc0':   (0x4a2cc0, 0x4a2e92),
    'caller-0x4bb230':  (0x4bb230, 0x4bb5a7),
    'pred-0x4bb670':    (0x4bb670, 0x4bb7f9),
}

def va2off(va):
    return va - TEXT_VA + TEXT_OFF

def main():
    data = open(BIN, 'rb').read()
    print('binary:', BIN)
    print('binary bytes:', len(data))
    print('binary sha256:', hashlib.sha256(data).hexdigest())
    # build-id from .note.gnu.build-id (readelf already validated section layout)
    import subprocess
    bid = subprocess.run(['readelf', '-n', BIN], capture_output=True, text=True).stdout
    for line in bid.splitlines():
        if 'Build ID' in line:
            print('build-id:', line.strip())
    print('va mapping: file_offset = va - 0x3290c0 + 0x3280c0  (delta 0x1000)')
    maplines = ['# va -> file offset (via .text: VA 0x3290c0 = file 0x3280c0)',
                '# range : va_start..va_end = file_start..file_end (bytes)']
    md = Cs(CS_ARCH_X86, CS_MODE_64)
    for name, (a, b) in RANGES.items():
        fa, fb = va2off(a), va2off(b)
        blob = data[fa:fb]
        open(f'{OUT}/{name}.bin', 'wb').write(blob)
        maplines.append(f'{name}: {a:#x}..{b:#x} = {fa:#x}..{fb:#x} ({len(blob)} bytes)')
        lines = [f'# {name}: VA {a:#x}..{b:#x} = file {fa:#x}..{fb:#x}',
                 '# Capstone x86-64; bytes are exact file bytes']
        for ins in md.disasm(blob, a):
            hx = ' '.join(f'{x:02x}' for x in ins.bytes)
            lines.append(f"{ins.address:#x}: {hx:<44} {ins.mnemonic} {ins.op_str}")
        open(f'{OUT}/{name}.dis.txt', 'w').write('\n'.join(lines) + '\n')
        print(f'wrote {name}.bin ({len(blob)} bytes) + {name}.dis.txt')
    open(f'{OUT}/va-map.txt', 'w').write('\n'.join(maplines) + '\n')
    print('wrote va-map.txt')

if __name__ == '__main__':
    main()
