"""Remote-only evidence collector authored locally by the research lead.

Execute in Muse's existing tool environment only. No interpretation, merchant
edits, extra requests, source/binary export, or hidden trace extraction.
"""
from pathlib import Path
from datetime import datetime, timezone
import csv
import hashlib
import json
import subprocess
import time
import zipfile

def now(): return datetime.now(timezone.utc).isoformat()
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
conditions = {
    'C0': ['--query', 'stainless steel frying pan'],
    'C1': ['--query', 'Misen stainless steel frying pan'],
    'C2': ['--query', 'stainless steel frying pan', '--brand', 'Misen'],
    'C3': ['--query', 'stainless steel frying pan', '--prefer-brand', 'Misen'],
    'C4': ['--query', 'stainless steel frying pan', '--domain', 'misen.com'],
    'C5': ['--query', 'stainless steel frying pan', '--brand', 'Misen', '--domain', 'misen.com'],
    'C6': ['--query', 'stainless steel frying pan', '--prefer-brand', 'Misen', '--domain', 'misen.com'],
}
common = ['-n', '50', '--conversation-id', 'misen-input-experiment-2026-09-26',
          '--retries', '0', '--timeout-secs', '30', '--raw', '--no-save']
orders = [['C0','C1','C2','C3','C4','C5','C6'],
          ['C1','C2','C3','C4','C5','C6','C0'],
          ['C2','C3','C4','C5','C6','C0','C1']]
stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
out=Path.home()/'workspace'/'research-evidence'/('misen-input-'+stamp)
out.mkdir(parents=True, exist_ok=False)
(out/'collector.py').write_bytes(Path(__file__).read_bytes())
(out/'schedule.json').write_text(json.dumps({'conditions':conditions,'common_args':common,'orders':orders},indent=2)+'\n')
executions=[]
unavailable=False
for block, order in enumerate(orders,1):
    for slot,condition in enumerate(order,1):
        number=(block-1)*7+slot
        run=f'R{number:02}'
        stem=f'{run}-{condition}'
        argv=['/opt/hatch/bin/meta-catalog-search']+conditions[condition]+common
        (out/(stem+'.argv.json')).write_text(json.dumps(argv,indent=2)+'\n')
        stdout=out/(stem+'.stdout.raw-bytes');stderr=out/(stem+'.stderr.raw-bytes')
        start=now();clock=time.monotonic();exit_code=None;error=None
        with stdout.open('wb') as so, stderr.open('wb') as se:
            try:
                process=subprocess.run(argv,stdout=so,stderr=se,timeout=45,check=False)
                exit_code=process.returncode
            except subprocess.TimeoutExpired:
                error='Collector timeout after 45 seconds; command not retried.'
            except (FileNotFoundError,PermissionError) as exc:
                error=f'{type(exc).__name__}: {exc}'
                unavailable=True
        record={'run_id':run,'block':block,'slot':slot,'condition_id':condition,
                'argv_exact_array':argv,'utc_start':start,'utc_end':now(),
                'elapsed_ms':round((time.monotonic()-clock)*1000,3),
                'exit_code':exit_code,'observed_error':error,
                'stdout_bytes':stdout.stat().st_size,'stdout_sha256':digest(stdout),'stderr_bytes':stderr.stat().st_size,'stderr_sha256':digest(stderr),'stderr_file':stderr.name,
                'conversation_id':'misen-input-experiment-2026-09-26',
                'query':conditions[condition][1],'num_results':50,'retry_count':0,
                'origin':'written by collector from this subprocess invocation; not manually transcribed'}
        (out/(stem+'.execution.json')).write_text(json.dumps(record,indent=2)+'\n')
        executions.append(record)
        if unavailable:break
    if unavailable:break
(out/'collection-status.json').write_text(json.dumps({'scheduled':21,'attempted':len(executions),'stopped_for_launch_error':unavailable,'completed_utc':now()},indent=2)+'\n')
files=sorted(p for p in out.iterdir() if p.is_file())
with (out/'MANIFEST.csv').open('w',newline='') as f:
    w=csv.writer(f);w.writerow(['path','bytes','sha256'])
    for p in files:w.writerow([p.name,p.stat().st_size,digest(p)])
archive=out.with_suffix('.zip')
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for p in sorted(out.iterdir()):
        if p.is_file():z.write(p,arcname=out.name+'/'+p.name)
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print(json.dumps({'archive_path':str(archive),'bytes':archive.stat().st_size,'sha256':digest(archive),'scheduled':21,'attempted':len(executions),'exit_codes':[r['exit_code'] for r in executions]},indent=2))
