from pathlib import Path
from datetime import datetime, timezone
import csv
import hashlib
import json
import random
import subprocess
import zipfile


def utc():
    return datetime.now(timezone.utc).isoformat()


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    root = Path.cwd() / ("catalog-upstream-color-" + stamp)
    root.mkdir(exist_ok=False)
    (root / "collector.py").write_bytes(Path(__file__).read_bytes())
    query = "32 oz stainless steel insulated water bottle"
    conditions = {"BASE": [], "GREEN": ["--color", "green"], "PREFER": ["--prefer-brand", "Hydro Flask"], "BRAND": ["--brand", "Hydro Flask"]}
    rng = random.Random(20260928)
    plan = []
    for repeat in range(1, 4):
        names = list(conditions)
        rng.shuffle(names)
        for name in names:
            argv = ["/opt/hatch/bin/meta-catalog-search", "--query", query] + conditions[name]
            argv += ["-n", "50", "--conversation-id", "upstream-color-20260927-Astra-01", "--retries", "0", "--timeout-secs", "30", "--raw"]
            plan.append({"run_id": f"R{len(plan)+1:02d}-{name}-{repeat}", "condition": name, "repeat": repeat, "argv": argv, "user_id_present": False})
    (root / "plan.json").write_text(json.dumps(plan, indent=2) + "\n")
    for item in plan:
        folder = root / item["run_id"]
        folder.mkdir()
        (folder / "argv.json").write_text(json.dumps(item["argv"], indent=2) + "\n")
        start = utc()
        exception = None
        try:
            result = subprocess.run(item["argv"], capture_output=True, timeout=40, check=False)
            stdout, stderr, exit_code = result.stdout, result.stderr, result.returncode
        except subprocess.TimeoutExpired as error:
            stdout, stderr, exit_code = error.stdout or b"", error.stderr or b"", None
            exception = "collector subprocess timeout at 40 seconds"
        except OSError as error:
            stdout, stderr, exit_code = b"", b"", None
            exception = repr(error)
        end = utc()
        (folder / "stdout.bin").write_bytes(stdout)
        (folder / "stderr.bin").write_bytes(stderr)
        receipt = dict(item, start_utc=start, end_utc=end, exit_code=exit_code, exception=exception, stdout_bytes=len(stdout), stderr_bytes=len(stderr), stdout_sha256=digest(folder / "stdout.bin"), stderr_sha256=digest(folder / "stderr.bin"))
        (folder / "execution.json").write_text(json.dumps(receipt, indent=2) + "\n")
    files = sorted(path for path in root.rglob("*") if path.is_file())
    with (root / "MANIFEST.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=["path", "bytes", "sha256"])
        writer.writeheader()
        for path in files:
            writer.writerow({"path": path.relative_to(root).as_posix(), "bytes": path.stat().st_size, "sha256": digest(path)})
    archive = root.with_suffix(".zip")
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as bundle:
        for path in sorted(root.rglob("*")):
            if path.is_file():
                bundle.write(path, path.relative_to(root.parent).as_posix())
    print(json.dumps({"archive_path": str(archive), "bytes": archive.stat().st_size, "sha256": digest(archive), "scheduled_calls": len(plan), "attempted_calls": len(list(root.glob("R*/execution.json")))}))


if __name__ == "__main__":
    main()
