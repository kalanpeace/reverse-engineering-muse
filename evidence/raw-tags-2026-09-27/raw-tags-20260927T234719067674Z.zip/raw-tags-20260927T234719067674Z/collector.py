#!/usr/bin/env python3
"""Astra raw-tags collection 2026-09-27.
ARM A: 12 category queries x 3 interleaved blocks (36 calls).
ARM B: 4 product queries x 3 interleaved blocks (12 calls).
Sequential calls; no --user-id; no retries; no replacements.
Stops on 3 consecutive failures or on 'Products unavailable',
'did not contain parseable product XML', or auth/rate error text.
"""
from datetime import datetime, timezone
from pathlib import Path
import csv
import hashlib
import json
import subprocess
import sys
import time
import zipfile

TOOL = Path("/opt/hatch/bin/meta-catalog-search")
CONV = "raw-tags-20260927-fixed"

ARM_A = [
    "stainless steel frying pan",
    "32 oz insulated water bottle",
    "everyday backpack",
    "office desk chair",
    "bath towel set",
    "men's running shoes",
    "women's dresses",
    "air purifier for a bedroom",
    "burr coffee grinder",
    "cotton bed sheets queen",
    "moisturizer for dry skin",
    "dog bed",
]
ARM_B = [
    "All-Clad D3 10 inch fry pan",
    "Hydro Flask 32 oz wide mouth",
    "Vitamix E310",
    "Levoit Core 300 air purifier",
]


def utc():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def tool_identity(tag):
    info = {"tag": tag, "utc": utc(), "path": str(TOOL)}
    try:
        st = TOOL.stat()
        info.update({
            "bytes": st.st_size,
            "sha256": sha(TOOL),
            "mode_oct": oct(st.st_mode & 0o777),
            "mtime_utc": datetime.fromtimestamp(st.st_mtime, timezone.utc).isoformat(),
        })
    except OSError as e:
        info["error"] = repr(e)
    return info


STOP_MARKERS = [
    "products unavailable",
    "did not contain parseable product xml",
    "rate limit",
    "too many requests",
    "permission denied",
    "unauthorized",
    "authentication failed",
    "access denied",
]


def main():
    root = Path.cwd() / ("raw-tags-" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ"))
    root.mkdir(exist_ok=False)
    (root / "collector.py").write_bytes(Path(__file__).read_bytes())
    identity = {"tool": str(TOOL), "before": tool_identity("before-first-call")}

    schedule = []
    for rep in (1, 2, 3):
        for i, q in enumerate(ARM_A, 1):
            schedule.append({"arm": "A", "repeat": rep, "query": q,
                             "run_id": f"A-R{rep}-Q{i:02d}"})
    for rep in (1, 2, 3):
        for i, q in enumerate(ARM_B, 1):
            schedule.append({"arm": "B", "repeat": rep, "query": q,
                             "run_id": f"B-R{rep}-Q{i:02d}"})
    (root / "schedule.json").write_text(json.dumps(schedule, indent=2) + "\n")

    errors = 0
    attempted = 0
    completed_ok = 0
    for item in schedule:
        dest = root / item["run_id"]
        dest.mkdir()
        argv = [str(TOOL), "--query", item["query"], "-n", "50",
                "--conversation-id", CONV, "--retries", "0",
                "--timeout-secs", "30", "--raw", "--no-save"]
        receipt = {
            "arm": item["arm"],
            "repeat": item["repeat"],
            "run_id": item["run_id"],
            "argv": argv,
            "start_utc": utc(),
            "exception": None,
        }
        try:
            result = subprocess.run(argv, capture_output=True, timeout=45, check=False)
            stdout, stderr, code = result.stdout, result.stderr, result.returncode
        except subprocess.TimeoutExpired as e:
            stdout, stderr, code = e.stdout or b"", e.stderr or b"", None
            receipt["exception"] = "collector timeout after 45 seconds"
        except OSError as e:
            stdout, stderr, code = b"", b"", None
            receipt["exception"] = repr(e)
        (dest / "stdout.bin").write_bytes(stdout)
        (dest / "stderr.bin").write_bytes(stderr)
        receipt.update({
            "end_utc": utc(),
            "exit_code": code,
            "stdout_bytes": len(stdout),
            "stderr_bytes": len(stderr),
            "stdout_sha256": sha(dest / "stdout.bin"),
            "stderr_sha256": sha(dest / "stderr.bin"),
        })
        (dest / "execution.json").write_text(json.dumps(receipt, indent=2) + "\n")
        attempted += 1
        ok = code == 0 and len(stdout) > 0
        if ok:
            completed_ok += 1
        errors = 0 if ok else errors + 1
        blob = (stderr + stdout[:4096]).decode("utf-8", "replace").lower()
        blocked = any(m in blob for m in STOP_MARKERS)
        print(json.dumps({"run_id": item["run_id"], "exit_code": code,
                          "stdout_bytes": len(stdout), "ok": ok,
                          "blocked_text": blocked}), flush=True)
        if errors >= 3 or blocked:
            (root / "STOP.json").write_text(json.dumps({
                "at": item["run_id"],
                "utc": utc(),
                "consecutive_failures": errors,
                "blocked_text_seen": blocked,
                "attempted": attempted,
                "completed_ok": completed_ok,
                "planned": len(schedule),
            }, indent=2) + "\n")
            break
        time.sleep(1)

    identity["after"] = tool_identity("after-last-call")
    (root / "tool-identity.json").write_text(json.dumps(identity, indent=2) + "\n")
    (root / "run-summary.json").write_text(json.dumps({
        "utc": utc(),
        "attempted": attempted,
        "planned": len(schedule),
        "completed_ok": completed_ok,
        "stopped": (root / "STOP.json").exists(),
    }, indent=2) + "\n")
    with (root / "MANIFEST.csv").open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["path", "bytes", "sha256"])
        w.writeheader()
        for p in sorted(root.rglob("*")):
            if p.is_file() and p.name != "MANIFEST.csv":
                w.writerow({"path": p.relative_to(root).as_posix(),
                            "bytes": p.stat().st_size, "sha256": sha(p)})
    archive = root.with_suffix(".zip")
    with zipfile.ZipFile(archive, "x", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(root.rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(root.parent).as_posix())
    print(json.dumps({"archive_path": str(archive),
                      "bytes": archive.stat().st_size,
                      "sha256": sha(archive),
                      "attempted": attempted,
                      "planned": len(schedule),
                      "stopped": (root / "STOP.json").exists()}), flush=True)


if __name__ == "__main__":
    main()
