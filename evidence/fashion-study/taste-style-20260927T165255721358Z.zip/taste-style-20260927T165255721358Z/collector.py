from pathlib import Path
from datetime import datetime, timezone
import csv
import hashlib
import json
import subprocess
import sys
import time
import zipfile


def utc():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    schedule_path = Path(sys.argv[1])
    schedule = json.loads(schedule_path.read_text())
    assert len(schedule) == 60 and len({q['run_id'] for q in schedule}) == 60
    root = Path.cwd() / ('taste-style-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'))
    root.mkdir(exist_ok=False)
    (root / 'collector.py').write_bytes(Path(__file__).read_bytes())
    (root / 'schedule.json').write_bytes(schedule_path.read_bytes())
    tool = Path('/opt/hatch/bin/meta-catalog-search')
    identity = {'path': str(tool)}
    try:
        identity.update({'before_bytes': tool.stat().st_size, 'before_sha256': sha(tool)})
    except OSError as e:
        identity['before_error'] = repr(e)
    errors = 0
    for q in schedule:
        dest = root / q['run_id']
        dest.mkdir()
        argv = [str(tool), '--query', q['query'], '-n', '50', '--conversation-id', 'taste-style-20260927-Astra-fixed', '--retries', '0', '--timeout-secs', '30', '--raw', '--no-save']
        receipt = {'author': 'Astra (gpt-6-astra)', 'query': q, 'argv': argv, 'start_utc': utc(), 'exception': None}
        try:
            result = subprocess.run(argv, capture_output=True, timeout=45, check=False)
            stdout, stderr, code = result.stdout, result.stderr, result.returncode
        except subprocess.TimeoutExpired as e:
            stdout, stderr, code = e.stdout or b'', e.stderr or b'', None
            receipt['exception'] = 'collector timeout after 45 seconds'
        except OSError as e:
            stdout, stderr, code = b'', b'', None
            receipt['exception'] = repr(e)
        (dest / 'stdout.bin').write_bytes(stdout)
        (dest / 'stderr.bin').write_bytes(stderr)
        receipt.update({'end_utc': utc(), 'exit_code': code, 'stdout_bytes': len(stdout), 'stderr_bytes': len(stderr), 'stdout_sha256': sha(dest / 'stdout.bin'), 'stderr_sha256': sha(dest / 'stderr.bin')})
        success = code == 0
        try:
            body = json.loads(stdout)
            responses = body.get('tool_responses', [])
            success = success and bool(responses) and all(x.get('success') is not False for x in responses)
        except (ValueError, AttributeError, TypeError):
            success = False
        receipt['collector_success'] = success
        (dest / 'execution.json').write_text(json.dumps(receipt, indent=2) + '\n')
        errors = 0 if success else errors + 1
        err = (stderr + stdout[:4096] if not success else stderr).decode('utf-8', 'replace').lower()
        denied = any(x in err for x in ['rate limit', 'too many requests', 'permission denied', 'unauthorized', 'authentication failed', 'access denied'])
        print(json.dumps({'run_id': q['run_id'], 'schedule_position': q['schedule_position'], 'exit_code': code, 'success': success}), flush=True)
        if errors >= 3 or denied:
            (root / 'STOP.json').write_text(json.dumps({'at': q['run_id'], 'utc': utc(), 'consecutive_failures': errors, 'access_or_rate_error': denied}, indent=2) + '\n')
            break
        time.sleep(1)
    try:
        identity.update({'after_bytes': tool.stat().st_size, 'after_sha256': sha(tool)})
    except OSError as e:
        identity['after_error'] = repr(e)
    (root / 'tool-identity.json').write_text(json.dumps(identity, indent=2) + '\n')
    with (root / 'MANIFEST.csv').open('w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=['path', 'bytes', 'sha256'])
        w.writeheader()
        for p in sorted(root.rglob('*')):
            if p.is_file() and p.name != 'MANIFEST.csv':
                w.writerow({'path': p.relative_to(root).as_posix(), 'bytes': p.stat().st_size, 'sha256': sha(p)})
    archive = root.with_suffix('.zip')
    with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED) as z:
        for p in sorted(root.rglob('*')):
            if p.is_file():
                z.write(p, p.relative_to(root.parent).as_posix())
    print(json.dumps({'archive_path': str(archive), 'bytes': archive.stat().st_size, 'sha256': sha(archive), 'attempted': len(list(root.glob('R*/execution.json'))), 'planned': 60, 'stopped': (root / 'STOP.json').exists()}), flush=True)


if __name__ == '__main__':
    main()
