from pathlib import Path
from datetime import datetime, timezone
import csv, hashlib, json, subprocess, time, zipfile, sys

def utc():
    return datetime.now(timezone.utc).isoformat()

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    schedule_path=Path(sys.argv[1])
    first,last=int(sys.argv[2]),int(sys.argv[3])
    schedule=json.loads(schedule_path.read_text())
    chosen=schedule[first-1:last]
    assert 1 <= first <= last <= 100 and len(chosen)==last-first+1
    root=Path.cwd()/('merchant-benchmark-'+f'{first:03d}-{last:03d}-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'))
    root.mkdir(exist_ok=False)
    (root/'collector.py').write_bytes(Path(__file__).read_bytes())
    (root/'queries.json').write_bytes(schedule_path.read_bytes())
    (root/'batch-plan.json').write_text(json.dumps({'author':'Astra','model':'gpt-6-astra','start_utc':utc(),'first':first,'last':last,'scheduled_queries':chosen,'requested_n':50,'user_id_present':False,'retries':0,'surface':'CLI raw stdout, not authenticated server body','stop':'3 consecutive failures or explicit rate/access/authentication error'},indent=2)+'\n')
    tool=Path('/opt/hatch/bin/meta-catalog-search')
    identity={'path':str(tool)}
    try: identity.update({'bytes':tool.stat().st_size,'before_sha256':sha(tool)})
    except OSError as e: identity['before_error']=repr(e)
    errors=0
    for q in chosen:
        p=root/q['id']
        p.mkdir()
        argv=[str(tool),'--query',q['query'],'-n','50','--conversation-id','merchant-benchmark-20260927-Astra-'+q['id'],'--retries','0','--timeout-secs','30','--raw','--no-save']
        receipt={'query':q,'argv':argv,'start_utc':utc(),'exception':None}
        try:
            result=subprocess.run(argv,capture_output=True,timeout=45,check=False)
            stdout,stderr,code=result.stdout,result.stderr,result.returncode
        except subprocess.TimeoutExpired as e:
            stdout,stderr,code=e.stdout or b'',e.stderr or b'',None
            receipt['exception']='collector timeout after45seconds'
        except OSError as e:
            stdout,stderr,code=b'',b'',None
            receipt['exception']=repr(e)
        (p/'stdout.bin').write_bytes(stdout)
        (p/'stderr.bin').write_bytes(stderr)
        receipt.update({'end_utc':utc(),'exit_code':code,'stdout_bytes':len(stdout),'stderr_bytes':len(stderr),'stdout_sha256':sha(p/'stdout.bin'),'stderr_sha256':sha(p/'stderr.bin')})
        (p/'execution.json').write_text(json.dumps(receipt,indent=2)+'\n')
        success=code==0
        try:
            parsed=json.loads(stdout)
            responses=parsed.get('tool_responses',[])
            if responses and any(x.get('success') is False for x in responses):success=False
        except (ValueError,AttributeError,TypeError):
            success=False
        errors=0 if success else errors+1
        error_text=(stderr+stdout[:4096] if not success else stderr).decode('utf-8','replace').lower()
        denied=any(t in error_text for t in ['rate limit','too many requests','permission denied','unauthorized','authentication failed','access denied'])
        if errors>=3 or denied:
            (root/'STOP.json').write_text(json.dumps({'at_query':q['id'],'consecutive_failures':errors,'access_or_rate_error':denied,'time_utc':utc()},indent=2)+'\n')
            break
        time.sleep(1)
    try: identity['after_sha256']=sha(tool)
    except OSError as e: identity['after_error']=repr(e)
    (root/'tool-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
    files=sorted(p for p in root.rglob('*') if p.is_file())
    with (root/'MANIFEST.csv').open('w',newline='') as out:
        w=csv.DictWriter(out,fieldnames=['path','bytes','sha256'])
        w.writeheader()
        for p in files:w.writerow({'path':p.relative_to(root).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)})
    archive=root.with_suffix('.zip')
    with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as out:
        for p in sorted(root.rglob('*')):
            if p.is_file():out.write(p,p.relative_to(root.parent).as_posix())
    print(json.dumps({'archive_path':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),'attempted':len(list(root.glob('Q*/execution.json'))),'planned':len(chosen),'stopped':(root/'STOP.json').exists()}))

if __name__=='__main__':
    main()
